
//
// This is example code from Chapter 8.6.2 "Global initialization" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

extern int y1;
int y2 = y1+2;    // y2 becomes 2 or 5
